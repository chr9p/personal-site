Jag ville få en 90-tals discokänsla på webbplatsen istället för en mer modern och minimalistisk design.
Med tanke på att det ju var en personsida ville jag inte att den skulle vara för simpel med "clean design"
utan jag ville testa något nytt.